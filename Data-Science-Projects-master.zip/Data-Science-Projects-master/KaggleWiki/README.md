# Parsing and using Wikipedia Data

## First Part - French governments

The first part aims to parse data from the French wikipedia website and pages about French governements. I am playing with data to get insights about governments : number of ministers, ministers' studies, etc.
